package magicGame.repositories.interfaces;

import magicGame.models.magicians.Magician;

import java.util.ArrayList;
import java.util.Collection;

public class MagicianRepositoryImpl implements MagicianRepository{

    private Collection<Magician> data;

    public MagicianRepositoryImpl() {
        this.data = new ArrayList<>();
    }

    @Override
    public Collection getData() {
        return null;
    }

    @Override
    public void addMagician(Magician model) {

    }

    @Override
    public boolean removeMagician(Magician model) {
        return false;
    }

    @Override
    public Object findByUsername(String name) {
        return null;
    }
}
