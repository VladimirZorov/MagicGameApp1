package magicGame.repositories.interfaces;

import magicGame.models.magics.Magic;

import java.util.ArrayList;
import java.util.Collection;

public class MagicRepositoryImpl implements MagicRepository{

    private Collection<Magic> data;

    public MagicRepositoryImpl() {
        this.data = new ArrayList<>();
    }

    @Override
    public Collection getData() {
        return null;
    }

    @Override
    public void addMagic(Magic model) {

    }

    @Override
    public boolean removeMagic(Magic model) {
        return false;
    }

    @Override
    public Object findByName(String name) {
        return null;
    }
}
